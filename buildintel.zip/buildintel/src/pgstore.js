// PostgreSQL persistence. Keeps the Store's synchronous in-memory API (so every module and test
// is unchanged) and writes each change to Postgres in a single transaction per save().
// Single writer: run ONE app instance against a database. Horizontal scaling needs the async
// query refactor described in docs/SCALING.md.
import pg from 'pg';
import { CORE_SCHEMA, CORE_TABLES, writeCoreRows } from './coredb.js';
import { Store } from './store.js';
import { pgTls } from './pgtls.js';
export { pgTls };

const SCHEMA = `
CREATE TABLE IF NOT EXISTS records (
  collection text NOT NULL,
  id text NOT NULL,
  org_id text,
  data jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (collection, id)
);
CREATE INDEX IF NOT EXISTS records_org_idx ON records (collection, org_id);
CREATE TABLE IF NOT EXISTS audit (
  id bigserial PRIMARY KEY,
  at timestamptz NOT NULL,
  actor text, org_id text, action text NOT NULL, target text, detail jsonb
);
CREATE INDEX IF NOT EXISTS audit_at_idx ON audit (at DESC);
CREATE TABLE IF NOT EXISTS schema_meta (key text PRIMARY KEY, value text);
INSERT INTO schema_meta VALUES ('version', '1') ON CONFLICT DO NOTHING;
`;


export class PgStore extends Store {
  /** Cross-server lock for scheduled jobs (PostgreSQL advisory lock). During a deploy the old and new servers overlap;
   *  without this both could run the hourly pull or the daily emails. Another server holding the lock = skip, not wait. */
  async withLock(name, fn) {
    const key = [...String('buildintel:' + name)].reduce((h, c) => (Math.imul(h, 31) + c.charCodeAt(0)) | 0, 7);
    const client = await this.pool.connect();
    try {
      const { rows } = await client.query('SELECT pg_try_advisory_lock($1) AS ok', [key]);
      if (!rows[0].ok) return { ran: false, skipped: `another server is running "${name}"` };
      try { return { ran: true, result: await fn() }; } finally { await client.query('SELECT pg_advisory_unlock($1)', [key]).catch(() => {}); }
    } finally { client.release(); }
  }
  constructor(url, { ssl } = {}) {
    super(null);
    this.tls = pgTls(url, ssl);
    this.pool = new pg.Pool({ connectionString: url, max: 4, ssl: this.tls.ssl });
    this.queue = Promise.resolve();
    this.lastFlushAt = null;
    this.lastFlushError = null;
    this.kind = 'postgres';
  }

  async init() {
    await this.pool.query(SCHEMA);
    await this.pool.query(CORE_SCHEMA);
    const { rows } = await this.pool.query('SELECT collection, id, data FROM records');
    for (const r of rows) if (this.data[r.collection]) this.data[r.collection][r.id] = r.data;
    // First start of schema v2 (or a table emptied by hand): copy core records into the relational tables.
    const empty = (await this.pool.query('SELECT count(*)::int AS n FROM bi_projects')).rows[0].n === 0;
    if (empty && Object.keys(this.data.projects || {}).length) {
      const client = await this.pool.connect();
      try { await client.query('BEGIN');
        await writeCoreRows(client, Object.keys(CORE_TABLES).flatMap(c => Object.values(this.data[c] || {}).map(r => [c, r])), []);
        await client.query('COMMIT'); } catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; } finally { client.release(); }
    }
    const a = await this.pool.query('SELECT at, actor, org_id, action, target, detail FROM audit ORDER BY id DESC LIMIT 5000');
    this.data.audit = a.rows.reverse().map(x => ({ at: x.at.toISOString(), actor: x.actor, orgId: x.org_id, action: x.action, target: x.target, detail: x.detail }));
    this.dirty.clear(); this.pendingAudit = [];
    return this;
  }

  /** Snapshot pending changes now (so later in-memory edits can't tear a write), flush in order. */
  save() {
    if (!this.dirty.size && !this.pendingAudit.length) return this.queue;
    const puts = []; const dels = []; const corePuts = []; const coreDels = [];
    for (const [key, op] of this.dirty) {
      const [c, id] = key.split('\u0000');
      const rec = this.data[c]?.[id];
      if (op === 'del' || !rec) { dels.push([c, id]); if (CORE_TABLES[c]) coreDels.push([c, id]); }
      else { puts.push([c, id, Store.isTenant(c) ? rec.orgId : (rec.orgId || null), JSON.stringify(rec)]); if (CORE_TABLES[c]) corePuts.push([c, structuredClone(rec)]); }
    }
    const audits = this.pendingAudit;
    const snapshotKeys = new Map(this.dirty);
    this.dirty.clear(); this.pendingAudit = [];
    this.queue = this.queue.then(() => this.#write(puts, dels, audits, corePuts, coreDels)).catch(err => {
      // Put the work back so the next save retries it; surface the error to readiness + health.
      for (const [k, v] of snapshotKeys) if (!this.dirty.has(k)) this.dirty.set(k, v);
      this.pendingAudit = [...audits, ...this.pendingAudit];
      this.lastFlushError = { at: new Date().toISOString(), message: err.message };
      console.error('postgres flush failed:', err.message);
    });
    return this.queue;
  }

  async #write(puts, dels, audits, corePuts = [], coreDels = []) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      if (puts.length) {
        await client.query(
          `INSERT INTO records (collection, id, org_id, data, updated_at)
           SELECT c, i, o, d::jsonb, now() FROM unnest($1::text[], $2::text[], $3::text[], $4::text[]) AS t(c, i, o, d)
           ON CONFLICT (collection, id) DO UPDATE SET data = EXCLUDED.data, org_id = EXCLUDED.org_id, updated_at = now()`,
          [puts.map(p => p[0]), puts.map(p => p[1]), puts.map(p => p[2]), puts.map(p => p[3])]);
      }
      if (dels.length) {
        await client.query('DELETE FROM records r USING unnest($1::text[], $2::text[]) AS t(c, i) WHERE r.collection = t.c AND r.id = t.i',
          [dels.map(d => d[0]), dels.map(d => d[1])]);
      }
      await writeCoreRows(client, corePuts, coreDels);   // relational core tables: same transaction, can't drift
      if (audits.length) {
        await client.query(
          `INSERT INTO audit (at, actor, org_id, action, target, detail)
           SELECT a, b, c, d, e, f::jsonb FROM unnest($1::timestamptz[], $2::text[], $3::text[], $4::text[], $5::text[], $6::text[]) AS t(a, b, c, d, e, f)`,
          [audits.map(x => x.at), audits.map(x => x.actor), audits.map(x => x.orgId), audits.map(x => x.action), audits.map(x => x.target), audits.map(x => JSON.stringify(x.detail ?? null))]);
      }
      await client.query('COMMIT');
      this.lastFlushAt = new Date().toISOString(); this.lastFlushError = null;
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      throw e;
    } finally { client.release(); }
  }

  async flushed() { this.save(); await this.queue; }
  async close() { await this.flushed(); await this.pool.end(); }

  /** One-time import of the pilot's JSON file into Postgres. */
  async importFrom(jsonStore) {
    for (const c of Store.COLLECTIONS) for (const [id, rec] of Object.entries(jsonStore.data[c] || {})) { this.data[c][id] = rec; this.mark(c, id); }
    this.pendingAudit = [...jsonStore.data.audit]; this.data.audit = [...jsonStore.data.audit];
    await this.flushed();
  }
}
