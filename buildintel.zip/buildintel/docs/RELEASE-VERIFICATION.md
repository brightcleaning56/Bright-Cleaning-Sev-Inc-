# Release verification

Result: **PASS — release verified**

- Verified at: 2026-11-05T04:34:12Z
- App version: 1.9.0 · lockfile sha256: 6358df2d1b722a3d
- Git commit: not a git checkout (zip)
- Node v22.22.2 · PostgreSQL: PostgreSQL 16.15
- Tests: test-ci: PASSED (tests 150, passed 150, failed 0, skipped 0, cancelled 0)
- Browser QA checks passed: off 9/9, on 9/9

| Step | Result | Time |
|---|---|---|
| Clean install (npm ci, lockfile) | PASS | 3s |
| Environment (Node, dependencies, PostgreSQL) | PASS | 0s |
| All automated tests (no failures, no skips) | PASS | 28s |
| Dependency security audit | PASS | 1s |
| Browser QA, CORE_READS=off | PASS | 294s |
| Browser QA, CORE_READS=on | PASS | 294s |

Logs: `/tmp/tmp.rtpb2YYice/logs` (kept on the machine that ran this).
